<template>
	<div class="bruce flex-ct-x" data-title="使用filter开启悼念模式">
		<img class="mourning-mode" src="https://static.yangzw.vip/codepen/car.jpg">
	</div>
</template>

<style lang="scss" scoped>
.mourning-mode {
	width: 400px;
	filter: grayscale(100%);
}
</style>