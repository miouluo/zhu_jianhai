# iDea CSS

[在线预览](https://yangzw.vip/idea-css/)

- 环境：`Node v16+`
- 安装：`npm i -g @yangzw/bruce-app`
- 进入目录：`cd icss`
- 构建项目：`bruce-app b`

请查看[Bruce FEES](https://JowayYoung.github.io/bruce)或[@yangzw/bruce-app](https://doc.yangzw.vip/bruce/app)的文档